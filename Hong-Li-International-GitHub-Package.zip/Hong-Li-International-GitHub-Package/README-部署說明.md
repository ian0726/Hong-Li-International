# 閎麗國際有限公司網站部署包

本壓縮檔包含兩個可各自建立 GitHub Repository 的專案：

- `Frontend-GitHub-Pages`：公開前台，部署到 GitHub Pages。
- `Backend-Cloudflare`：管理後台、API、D1 資料庫與 R2 檔案空間，部署到 Cloudflare Workers。

建議先完成後台，再部署前台。

## 一、部署 Cloudflare 後台

先在電腦安裝 Node.js 22 LTS，解壓縮後用終端機進入 `Backend-Cloudflare`。

```bash
npm install
npx wrangler login
npx wrangler d1 create hong-li-international-db
npx wrangler r2 bucket create hong-li-international-files
```

建立 D1 後，Cloudflare 會顯示一組 `database_id`。開啟 `wrangler.jsonc`，用該 ID 取代：

```text
00000000-0000-4000-8000-000000000000
```

接著建立資料表並部署：

```bash
npm run deploy:database
npm run deploy
```

部署完成後會得到類似網址：

```text
https://hong-li-international-backend.<你的帳號>.workers.dev
```

後台位置：

```text
https://hong-li-international-backend.<你的帳號>.workers.dev/admin
```

第一次進入後台會建立第一位管理員帳號。

## 二、把後台程式碼放到 GitHub

建立一個新的 Private Repository，例如 `hong-li-international-backend`，將 `Backend-Cloudflare` 資料夾裡面的內容全部上傳。

若使用內附的 GitHub Actions 自動部署，請在 Repository 的 `Settings → Secrets and variables → Actions → Secrets` 新增：

- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_API_TOKEN`

API Token 必須具備 Workers、D1 與 R2 所需權限。不要把 Token、管理員密碼、`.env` 或 `.dev.vars` 寫進程式碼。

## 三、部署 GitHub Pages 前台

建立另一個 Repository，例如 `hong-li-international-frontend`，將 `Frontend-GitHub-Pages` 資料夾裡面的內容全部上傳。

在前台 Repository 開啟：

```text
Settings → Secrets and variables → Actions → Variables
```

新增變數：

```text
Name: VITE_API_BASE_URL
Value: https://hong-li-international-backend.<你的帳號>.workers.dev
```

網址結尾不要加 `/`，也不要填 `/admin` 或 `/api/products`。

接著到 `Settings → Pages`，將 Source 選成 `GitHub Actions`。在 `Actions` 頁面執行 `Deploy GitHub Pages`，完成後會取得公開前台網址。

## 四、前後台如何連動

- 前台透過 `VITE_API_BASE_URL` 讀取 Cloudflare API。
- 商品、分類、品牌、圖片、影片、PDF、Excel 與聯絡 Email 都在後台管理。
- 商品資料存入 D1；圖片、影片檔案、PDF 與 Excel 原檔存入 R2。
- 後台更新商品後，重新整理 GitHub Pages 即可看到新資料，不必重新部署前台。
- 只有修改前台程式、版面或 Worker 網址時，才需要重新執行 GitHub Pages 部署。

## 五、Excel 匯入規則

- 必填：商品分類、品牌、車型。
- 其他欄位可留空，系統會依既有規則匯入。
- 多張圖片網址放在圖片欄，以半形逗號 `,` 分隔。
- 多個影片網址放在影片欄，以半形逗號 `,` 分隔。
- 商品沒有圖片時，會套用該商品分類在後台設定的預設圖片。
- 圖片與影片也可在後台針對單一商品新增、編輯或刪除。

## 六、上線前檢查

- `/api/products` 可以顯示 JSON。
- `/admin` 可以建立帳號並登入。
- Excel 可匯入，且錯誤列會顯示原因。
- 前台兩種搜尋方式都能找到商品。
- 商品詳情可切換多張圖片與影片。
- 無商品圖片時會顯示分類預設圖片。
- GitHub Pages 的聯絡按鈕使用後台設定的 Email。
